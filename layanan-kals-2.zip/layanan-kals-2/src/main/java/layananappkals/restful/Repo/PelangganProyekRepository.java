package layananappkals.restful.Repo;

import layananappkals.restful.Models.PelangganProyek;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PelangganProyekRepository extends JpaRepository<PelangganProyek, Long> {
}

