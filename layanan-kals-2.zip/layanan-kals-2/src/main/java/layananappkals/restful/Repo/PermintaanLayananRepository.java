package layananappkals.restful.Repo;

import layananappkals.restful.Models.PermintaanLayanan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermintaanLayananRepository extends JpaRepository<PermintaanLayanan, Long> {

}
