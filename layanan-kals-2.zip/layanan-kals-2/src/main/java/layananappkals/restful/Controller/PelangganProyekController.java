package layananappkals.restful.Controller;

import layananappkals.restful.Models.PelangganProyek;
import layananappkals.restful.Repo.PelangganProyekRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pelangganproyek")
public class PelangganProyekController {
    @Autowired
    private PelangganProyekRepository pelangganProyekRepository;

    @GetMapping
    public List<PelangganProyek> getAllPelangganProyek() {
        return pelangganProyekRepository.findAll();
    }

    @PostMapping
    public PelangganProyek createPelangganProyek(@RequestBody PelangganProyek pelangganProyek) {
        return pelangganProyekRepository.save(pelangganProyek);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PelangganProyek> updatePelangganProyek(@PathVariable Long id, @RequestBody PelangganProyek pelangganProyekDetails) {
        Optional<PelangganProyek> optionalPelangganProyek = pelangganProyekRepository.findById(id);
        if (!optionalPelangganProyek.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        PelangganProyek existingPelangganProyek = optionalPelangganProyek.get();
        existingPelangganProyek.setId_proyek(pelangganProyekDetails.getId_proyek());

        return ResponseEntity.ok(pelangganProyekRepository.save(existingPelangganProyek));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePelangganProyek(@PathVariable Long id) {
        Optional<PelangganProyek> pelangganProyek = pelangganProyekRepository.findById(id);
        if (!pelangganProyek.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        pelangganProyekRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }



}
