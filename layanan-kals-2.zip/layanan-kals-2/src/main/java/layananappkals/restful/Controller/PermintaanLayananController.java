package layananappkals.restful.Controller;

import layananappkals.restful.Models.PermintaanLayanan;
import layananappkals.restful.Repo.PermintaanLayananRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/permintaan-layanan")
public class PermintaanLayananController {
    @Autowired
    private PermintaanLayananRepository permintaanLayananRepository;

    @GetMapping
    public List<PermintaanLayanan> getAllPermintaanLayanan() {
        return permintaanLayananRepository.findAll();
    }

    @PostMapping
    public PermintaanLayanan createPermintaanLayanan(@RequestBody PermintaanLayanan permintaanLayanan) {
        return permintaanLayananRepository.save(permintaanLayanan);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PermintaanLayanan> updatePermintaanLayanan(@PathVariable Long id, @RequestBody PermintaanLayanan permintaanLayananDetails) {
        Optional<PermintaanLayanan> optionalPermintaanLayanan = permintaanLayananRepository.findById(id);
        if (!optionalPermintaanLayanan.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        PermintaanLayanan existingPermintaanLayanan = optionalPermintaanLayanan.get();
        existingPermintaanLayanan.setNamaPengirim(permintaanLayananDetails.getNamaPengirim());
        existingPermintaanLayanan.setNamaPenerima(permintaanLayananDetails.getNamaPenerima());
        existingPermintaanLayanan.setTanggal(permintaanLayananDetails.getTanggal());
        existingPermintaanLayanan.setJumlahPermintaan(permintaanLayananDetails.getJumlahPermintaan());
        existingPermintaanLayanan.setTotal(permintaanLayananDetails.getTotal());

        return ResponseEntity.ok(permintaanLayananRepository.save(existingPermintaanLayanan));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePermintaanLayanan(@PathVariable Long id) {
        Optional<PermintaanLayanan> permintaanLayanan = permintaanLayananRepository.findById(id);
        if (!permintaanLayanan.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        permintaanLayananRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }


}
