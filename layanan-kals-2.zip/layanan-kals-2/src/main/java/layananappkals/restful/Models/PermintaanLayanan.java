package layananappkals.restful.Models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "permintaan_layanan")
public class PermintaanLayanan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long pelanggan_id;
    private Long jenis_layanan_id;
    private String namaPengirim;
    private String namaPenerima;
    private Date tanggal;
    private int jumlahPermintaan;
    private BigDecimal total;


    public Long getPelanggan_id() {
        return pelanggan_id;
    }

    public void setPelanggan_id(Long pelanggan_id) {
        this.pelanggan_id = pelanggan_id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getJenis_layanan_id() {
        return jenis_layanan_id;
    }

    public void setJenis_layanan_id(Long jenis_layanan_id) {
        this.jenis_layanan_id = jenis_layanan_id;
    }

    public String getNamaPengirim() {
        return namaPengirim;
    }

    public void setNamaPengirim(String namaPengirim) {
        this.namaPengirim = namaPengirim;
    }

    public String getNamaPenerima() {
        return namaPenerima;
    }

    public void setNamaPenerima(String namaPenerima) {
        this.namaPenerima = namaPenerima;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public int getJumlahPermintaan() {
        return jumlahPermintaan;
    }

    public void setJumlahPermintaan(int jumlahPermintaan) {
        this.jumlahPermintaan = jumlahPermintaan;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

}
