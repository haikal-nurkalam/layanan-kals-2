package layananappkals.restful.Models;


import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
@Table(name = "pelanggan_proyek")
public class PelangganProyek {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_pelanggan;

    private Long id_proyek;


    public Long getId_pelanggan() {
        return id_pelanggan;
    }

    public void setId_pelanggan(Long id_pelanggan) {
        this.id_pelanggan = id_pelanggan;
    }

    public Long getId_proyek() {
        return id_proyek;
    }

    public void setId_proyek(Long id_proyek) {
        this.id_proyek = id_proyek;
    }


}
