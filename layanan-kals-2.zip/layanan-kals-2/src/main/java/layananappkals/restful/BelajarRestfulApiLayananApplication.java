package layananappkals.restful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarRestfulApiLayananApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarRestfulApiLayananApplication.class, args);
	}

}
