CREATE DATABASE 05TPLE001_kalsssssss;

USE 05TPLE001_kalsssssss;









CREATE TABLE pelanggan_proyek (
                                  id_pelanggan INT NOT NULL AUTO_INCREMENT,
                                  id_proyek INT NOT NULL,
    primary key (id_pelanggan)
) ENGINE=InnoDB;


CREATE TABLE permintaan_layanan (
                                    id INT NOT NULL AUTO_INCREMENT,
                                    pelanggan_id INT NOT NULL,
                                    jenis_layanan_id INT NOT NULL,
                                    nama_pengirim CHAR(50) NOT NULL,
                                    nama_penerima CHAR(50) NOT NULL,
                                    tanggal DATE NOT NULL,
                                    jumlah_permintaan INT NOT NULL,
                                    total DECIMAL(10,2) NOT NULL,
                                    PRIMARY KEY (id)
) ENGINE=InnoDB;








